# Skyra LogHub — Phase 4 Implementation Roadmap: Web Console & Observability Experience

**Document Version:** 1.0.0  
**Status:** Approved Architecture Specification  
**Task ID:** `LOGHUB-CONSOLE-001`  
**Phase:** Phase 4 — Web Console, Administration & Observability Experience  
**Date:** 2026-10-27  

---

## 1. Phase 4 Task Sequencing & Milestone Flow

Phase 4 delivers the complete web-based observability workstation for Skyra LogHub. Tasks are structured sequentially to ensure foundational design systems and verified Query APIs are implemented first, while clearly cordoning administrative screens behind required backend API milestones:

```text
LOGHUB-CONSOLE-001 (Architecture, Design System & Contracts)  [PASS]
         │
         ▼
LOGHUB-CONSOLE-002 (Angular Foundation, Shell & Design Tokens) [PASS]
         │
         ▼
LOGHUB-CONSOLE-003 (Core API Client, Session & Workspace Context) [PASS]
         │
         ▼
LOGHUB-CONSOLE-004 (Log Explorer & Canonical Event Drawer)     [PASS]
         │
         ▼
LOGHUB-CONSOLE-005 (Observability Overview & Analytics Dashboards) [PASS]
         │
         ▼
LOGHUB-ADMIN-001 (Administration Backend Architecture & Contracts) [PASS]
         │
         ▼
[Backend Milestones: LOGHUB-ADMIN-002 -> ADMIN-005]
         │
         ▼
LOGHUB-CONSOLE-006 (Project & Ingestion Credential Administration) [NEXT]
         │
         ▼
LOGHUB-CONSOLE-007 (Performance, Security, Accessibility & E2E Hardening)
         │
         ▼
LOGHUB-CONSOLE-008 (Phase 4 Final Functional & Operational Acceptance)
```

---

## 2. Detailed Milestone Definitions

### LOGHUB-CONSOLE-001: Architecture, Product Design & API Integration Planning
- **Status:** Complete (PASS).
- **Scope:** Architecture review, UX design system, CSS custom property tokens, screen wireframes, API gap analysis, security threat model, and 5 new ADRs (ADR-022 to ADR-026).
- **Deliverables:** `docs/console/01-` through `11-`, `SKYRA_LOGHUB_CONSOLE_001_ARCHITECTURE_REPORT.md`.

### LOGHUB-CONSOLE-002: Angular Foundation, Shell & Design Tokens
- **Target:** Initialize `apps/console-web` with Angular 19 standalone components.
- **Scope:**
  - Setup Angular 19 workspace package in `apps/console-web/`.
  - Implement token-driven CSS styling with active Light/Dark mode switcher.
  - Implement core layout shell (collapsible sidebar, global top bar, breadcrumbs).
  - Implement functional `AuthGuard` and local dev mock authentication provider.
- **Verification:** Unit tests for shell components, theme toggling, and route guards.

### LOGHUB-CONSOLE-003: Core API Client, Session & Workspace Context
- **Target:** Strongly typed API integration and global tenant/project context management.
- **Scope:**
  - Implement `QueryApiClient` backed by `HttpClient` adhering to `contracts/query/v1/`.
  - Implement functional interceptors for Bearer auth and RFC 7807 error handling.
  - Implement Workspace Context Service managing active tenant, authorized projects, and global time-range filters with URL query-string synchronization.
- **Verification:** Contract tests mocking Query Service endpoints and verifying DTO serialization.

### LOGHUB-CONSOLE-004: Log Explorer & Canonical Event Drawer
- **Status:** Complete (PASS).
- **Target:** Primary incident investigation workstation.
- **Scope:**
  - Implement structured query input with debounced execution and validation.
  - Implement high-density log table with millisecond timestamps and ECS severity badges.
  - Implement bidirectional keyset cursor pagination (`pagination.next_cursor` stack with in-memory previous page history).
  - Implement dynamic facets for log level, service name, and environment.
  - Implement slide-out Event Detail Drawer with Formatted Fields, Raw JSON syntax viewer (zero innerHTML), and trace correlation actions.
- **Verification:** Unit tests, component tests, cursor pagination state tests, BFF query proxy integration tests, and full monorepo regressions (729/729 passing).

### LOGHUB-CONSOLE-005: Observability Overview & Analytics Dashboards
- **Status:** Complete (PASS).
- **Target:** Operational KPI metrics, date histograms, severity distributions, and dynamic drilldowns.
- **Scope:**
  - Implement Overview Dashboard KPI cards (Total events, error counts, warning counts, active services).
  - Implement interactive native SVG UTC date histogram chart with hover tooltips and WCAG 2.2 AA tabular fallback.
  - Implement Severity distribution and Top Reporting Services components.
  - Implement Analytics Workspace (`/analytics`) with multi-dimensional terms aggregations (`error.type`, `event.action`).
  - Implement one-click drilldowns to Log Explorer preserving time-range bounds and filter dimensions.
  - Enforce monotonic query cancellation and cross-tenant state wiping.
- **Verification:** Unit tests, component tests, facade state tests, BFF aggregation integration tests, and full monorepo regressions (748/748 passing).

### [Backend Milestone] LOGHUB-ADMIN-001: Administration Backend Architecture & Contracts
- **Status:** Complete (PASS — Architecture Ready).
- **Target:** Architecture, security threat modeling, RBAC hierarchy, OpenAPI 3.1 contracts, and additive database migration proposal.
- **Scope:**
  - Author 12 specifications in `docs/admin/`.
  - Author 7 new ADRs (ADR-027 through ADR-033).
  - Versioned OpenAPI 3.1 & JSON Schemas in `contracts/admin/v1/`.
  - Automated contract verification suite passing 7/7 tests (52/52 monorepo contract tests).

### [Backend Milestones] LOGHUB-ADMIN-002 through ADMIN-005
- **ADMIN-002:** Approved Prisma Migration, IAM Entities & Authoritative Membership Provider.
- **ADMIN-003:** Tenant, Project & Membership REST APIs.
- **ADMIN-004:** Ingestion Credential, Quota & Retention APIs.
- **ADMIN-005:** Administration Security Hardening & Acceptance.

### LOGHUB-CONSOLE-006: Project & Ingestion Credential Administration
- **Target:** Administrative management screens (`/projects`, `/ingestion`, `/team`).
- **Prerequisite:** Completion of `LOGHUB-ADMIN-004`.
- **Scope:**
  - Project listing and quota editing view.
  - Ingestion credential generation with secure one-time secret display and revocation modal.
- **Verification:** RBAC route guard tests and credential generation workflow tests.

### LOGHUB-CONSOLE-007: Performance, Security, Accessibility & E2E Hardening
- **Target:** Production readiness and enterprise quality gates.
- **Scope:**
  - Virtualization and rendering performance optimization for 500+ table rows.
  - Full keyboard shortcuts (`j`/`k`, `Enter`, `Esc`, `/`).
  - Automated Axe-Core accessibility audit guaranteeing WCAG 2.2 AA compliance.
  - Comprehensive Playwright E2E test suite covering primary user journeys.
- **Verification:** Zero Axe-Core violations, sub-100ms UI interaction latency, clean E2E passes.

### LOGHUB-CONSOLE-008: Phase 4 Final Acceptance & Operational Release
- **Target:** Final independent Phase 4 acceptance certification.
- **Scope:** Full regression testing across monorepo, documentation reconciliation, and operational handover.
