# Security, Authentication and Authorization Specification

> **Product:** Skyra LogHub  |  **Status:** Proposed baseline — review before implementation  |  **Version:** 0.1-draft  |  **Date:** 2026-10-21
> **Repository:** `skyra-loghub` (renamed by project owner). Assumptions and undecided items are marked **TBD**. These documents are design specifications, not assertions that code already exists.

## 1. Security objectives and threat model
Protect production diagnostics, developer identities, project boundaries, MCP access and ingestion credentials. Threats include credential theft, malicious log injection/XSS, unbounded DuckDB query and file-path abuse, prompt injection through logs, cross-project leakage, insecure remote log submission, log tampering, exfiltration via export and resource exhaustion.

## 2. Human authentication
- OIDC provider **TBD** (Microsoft Entra ID or another validated provider); require MFA enforced at provider.
- Authorization Code + PKCE where applicable; server-managed sessions with short-lived secure `HttpOnly`, `Secure`, appropriately `SameSite` cookies; CSRF defense for state-changing cookie-authenticated APIs.
- Secure session rotation, logout, idle/absolute expiration, account disable and device/session revocation; log security events without secrets.
- Prefer same-origin reverse proxy for Angular→API to minimize cross-origin cookie complexity; disallow wildcard CORS with credentials.

## 3. Roles and project scoping
| Role | Permissions |
|---|---|
| `super_admin` | System configuration, controlled cross-project operations, membership governance |
| `project_admin` | Project-scoped roles, searches, approved source settings |
| `developer` | Assigned project queries, traces/errors, saved views |
| `viewer` | Read-only sanitized search in assigned projects |
All data APIs and MCP tools enforce membership **server-side** per request and apply query-level project/environment filters. UI hiding is not security. Export is separate permission; administrative scopes never default on.

## 4. Machine/API token model
- **Opaque personal/service access tokens** for supported automation clients: high-entropy random bytes, prefixed non-secret lookup ID, one-time reveal, keyed hash/HMAC verifier at rest, key rotation strategy.
- Metadata: credential ID, owner service/user, allowed project IDs, scopes, createdBy, createdAt, expiresAt, lastUsedAt, revokedAt, issuance purpose, optional network restriction.
- Suggested short defaults: 7 days personal token; service credentials use bounded rotation intervals set by policy; maximum validity 30 days unless explicit admin exception; never unlimited validity for new tokens.
- Verify token validity, revocation, principal active state, allowed scope and project at every access (cache with immediate invalidation). Use constant-time verifier comparison.
- UI create/list/revoke/rotate, once-only secret display and access audit. Never store/log raw tokens, even in audit entries or error messages.
- Token issuance and rotation restricted by role; cannot grant scope beyond issuer's effective access (anti-escalation).

## 5. OAuth for remote MCP
Remote MCP access follows its supported OAuth protected-resource flow; require audience-bound access tokens, discovery metadata, verifiable issuer, expiry, scopes, user/client identity and resource restrictions. **API keys cannot simply be treated as OAuth bearer tokens without a validated auth bridge.** Check actual Antigravity/Claude Code MCP client behavior during integration; support authorized local stdio with credential injection where necessary.

## 6. Ingestion identity & Browser Perimeter (ADR-012, ADR-015)
- **Machine Authentication:** Dedicated service/agent Bearer tokens (`Authorization: Bearer <token>`). Tokens are 256-bit high-entropy opaque strings hashed with SHA-256 in PostgreSQL (`ingestion_credentials`). The previously proposed `X-Skyra-Proxy-Secret` header is deprecated in favor of standard Bearer authentication.
- **Tenant & Project Binding:** Credentials map strictly to authorized `tenant_id`, `allowed_projects`, and `allowed_environments`. The gateway rejects batches declaring unauthorized project IDs (`403 PROJECT_ACCESS_DENIED`). Clients cannot supply or forge `tenant_id`.
- **Zero Browser Secrets:** Browser bundles (@skyra/logger-browser, Angular, React) must NEVER embed ingestion tokens or database credentials. Browser telemetry traverses an authenticated same-origin application backend proxy with session authorization, CSRF protection, and rate limiting.
- **Durable Replay Resistance:** Idempotency is enforced authoritatively via crash-recoverable WAL journal and persistent receipt index (7-day retention). Reusing a batch ID with modified payload is rejected with `409 IDEMPOTENCY_CONFLICT`. Valkey is strictly an optional acceleration cache.

## 7. Rate limiting (initial nonbinding configuration)
| Surface | Starter cap | Additional enforcement |
|---|---|---|
| Failed login | 5 per 15min per account/IP combination | progressive delays; avoid attacker-forced lockout |
| Search | 60/min/user | max 24h initial window, result page cap, timeout, aggregation budget |
| Export | 5/hour/user | async job, max bytes, full audit |
| Machine/MCP | 30/min/credential | per-project scopes and output cap |
| Ingest | configurable per source | EPS/batch/size/disk budgets and backpressure |
Distributed counters in Redis/Valkey; use gateway/WAF controls for high-volume abuse. Validate defaults via load tests and legitimate usage; account for NAT and proxy IP trust.

## 8. Application/API hardening
- Secure headers, CSP with no unnecessary inline script, input validation and output encoding; JSON viewer treats logs as **untrusted strings**, no innerHTML.
- Query API uses allowlisted parsed AST with fixed authenticated project filters, short timeouts, result caps, cancellation, query depth and field cardinality limits.
- Protect against SSRF in webhook/URL inputs; egress restrictions, DNS/IP checks; no log-message URLs auto-opened.
- Dependency scanning, SBOM, signed/pinned container images, least-privilege runtime, read-only filesystem where feasible and no root containers.

## 9. Data protection and storage
TLS internal/external; encrypted volumes/backups; secrets via vault/provider; PostgreSQL and central JSONL/Parquet storage and DuckDB query service private endpoints. Segregate operational logs vs tamper-evident security audit record. Audit login, token issue/revoke, access denial, role changes, queries and exports; audit records must never reveal raw secrets or confidential query results.

## 10. Logging privacy rules
SDK sanitizes first; ingestion sanitizes again. Prohibit authentication headers, cookies, body dumps, SQL bind parameters, AI prompts and sensitive IDs by default. Apply field allowlist, nested object sanitization and bounded size; review retention and data residency with stakeholders before production use.

## 11. Security test gate matrix
| Test | Expected result |
|---|---|
| Project A token requests B | 403, no data, audited |
| Expired/revoked token | 401/403 without grace leakage |
| Stolen token attempts scope elevation | Denied server side |
| Malicious log string `<script>` | Rendered as plain text |
| Arbitrary ES DSL/Skyra Query Language commands | Reject unsupported/unscoped statements |
| Flood oversized JSON/batches | Reject/throttle without service crash |
| MCP attempts log-driven prompt injection | Tool remains read-only and scoped |
| Session CSRF and logout | State mutation protected, old session invalid |
| Redaction fixtures (nested secrets/SQL) | Secrets absent from files/index/search/export |

## 12. Incident response
Revoke compromised credential and sessions, check audits, rotate related secrets, quarantine suspicious source, preserve signed relevant evidence under restricted access, restore/backfill as appropriate and document impact. Define incident owner/rotation and notification channel **TBD**.


## File/query-engine threat model extension
- Only ingestion/archive worker credentials may write central JSONL. Apply restrictive directory/object ACLs, safe fixed prefixes, no traversal/symlinks, encryption in transit/at rest, integrity hashing and audit of archive access. Project IDs are resolved against registered service identities, not trusted from submitted paths.
- Query workers must run sandboxed/unprivileged with read-only, project-scoped manifest/file access. Disallow arbitrary DuckDB external extensions, local file paths, attach/install/copy statements, unrestricted SQL and side-effecting functions; compile a restricted query AST to bounded SQL.
- Reports and Jarvis-generated definitions must pass the same project authorization, field allowlist, result caps, timeouts, cache isolation and redaction rules. Report publication/change/create is auditable; Jarvis high-risk administrative actions require separate approval.
- PostgreSQL contains accounts/project membership/tokens/report definitions only (no raw app log-event rows); maintain independent security audit trail.

## Q-02 fail-closed configuration invariants

- The Angular console starts unauthenticated. Preview authentication is available only when runtime configuration explicitly sets `environment: development`, `previewMode: true` and `previewIsolation: true`; preview user/workspace fixtures are supplied by that isolated runtime configuration and are never seeded in the production bundle.
- Production-classified BFF and Administration Service startup requires explicitly injected, non-placeholder session, CSRF and internal/service assertion secrets. Mock OIDC and development signer values are rejected rather than silently downgraded.
- Production Query Service startup rejects test authentication, wildcard CORS, missing JWT/JWKS configuration and placeholder cursor/JWT signing values. CORS is an origin policy only and never substitutes for bearer or tenant/project authorization.
- These invariants are configuration gates; they do not replace server-side membership, tenant/project scope, CSRF, session or credential controls described above.

### Q-02A dependency security remediation baseline

- **NestJS 11 & Fastify 5 Migration**: Backend services (`admin-service`, `console-bff`, `ingestion-gateway`, `query-service`, `@skyra/logger-nestjs`) run on NestJS `11.2.11` and Fastify `5.12.8`, resolving critical `@fastify/middie` child-plugin scope authentication bypass (GHSA-72c6-fx6q-fr5w / 1116760) and high URL-encoding middleware bypasses (GHSA-v9hr-23jh-mwc8, GHSA-j643-4mcp-h2m5, GHSA-cxrg-g7r8-w69p).
- **Angular 20 Migration**: The Web Console (`@skyra/console-web`) and Angular SDK adapter (`@skyra/logger-angular`) run on Angular `20.3.35` and TypeScript `5.8.3`, resolving Angular 19 high advisories (1123497, 1123501, 1123560, 1130677, 1130693, 1240616, 1242591) without requiring modifications to immutable Skyra Platform custom elements.
- **Transitive Multer Resolution**: Transitive `multer` upgraded to `2.5.0` via `@nestjs/platform-express@11.2.11`; confirmed unreachable at runtime as all production microservices utilize `@nestjs/platform-fastify` with zero multipart file upload attack surfaces.
- **Zero Production Advisories**: Authoritative production audit scan (`pnpm audit --prod`) confirms 0 critical, 0 high, 0 moderate, and 0 low vulnerabilities across all 204 production dependencies.


## 13. Browser Client Security Boundaries (@skyra/logger-browser, Angular, React)
- **Zero Server Credentials**: Browser client bundles must NEVER embed ingestion secret tokens, database credentials, server API keys, or private storage credentials.
- **Pre-Buffering In-Memory Sanitization**: Redaction executes synchronously prior to buffering in memory, ensuring unredacted secrets never exist in transmission queues or heap dumps.
- **Cross-Origin & Network Protections**:
  - `credentials: "omit"` by default on cross-origin requests to prevent ambient cookie leakage.
  - Strict HTTPS enforcement for all non-localhost remote HTTP ingestion endpoints.
  - Destination origin allowlisting (`allowedOrigins`) prevents leaking W3C traceparents and logs to arbitrary third-party endpoints.
- **Bounded Resource Defense**: Strict queue bounds (events and memory bytes) protect against memory exhaustion attacks, with priority eviction ensuring critical error events are preserved while dropping low-severity events under load.
- **Global Error Sanitization**: Error listeners sanitize stack traces, normalize cross-origin `Script error.` messages, and redact sensitive tokens and credentials from message strings.

## 14. Cross-SDK Shared Security Verification (LOGHUB-PKG-007)
- **Shared Security Fixtures Corpus**: Golden security fixtures (`security-sensitive-nested-metadata.json` and `security-url-credentials.json`) must pass identical redaction tests across Node.js, Python, and Browser SDKs. All sensitive keys (`password`, `token`, `secret`, `api_key`, `credit_card`, `authorization`, `cookie`, `connection_string`) are deeply masked as `[REDACTED]`.
- **Safe Fallback Safeguard (DEF-001)**: React `useSkyraLogger()` called outside of `<SkyraLoggerProvider>` utilizes `SafeNoopBrowserLogger`. It emits a single development-time console warning and operates as a complete no-op—allocating zero queues, registering zero event listeners, and transmitting zero unrouted network requests.
- **Privacy-Safe Crash Quarantine**: Incomplete or corrupted log lines recovered during crash recovery are recorded to `.corrupt.log` with a SHA-256 hash and byte offset only. Raw plaintext fragments are strictly quarantined without leaking secrets.
- **Envelope Immutability Guarantee**: User-supplied business metadata can never overwrite canonical envelope security fields (`@timestamp`, `ecs.version`, `skyra.project_id`, `skyra.schema_version`, `event.id`, `service.name`, `service.environment`). All canonical properties are defended against prototype pollution and object overriding.
